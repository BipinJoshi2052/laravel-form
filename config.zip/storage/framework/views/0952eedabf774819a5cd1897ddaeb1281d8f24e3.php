

<?php $__env->startSection('content'); ?>
    <div class = "container">
        <div class = "row justify-content-center">
            <div class = "col-md-8">
                <div class = "card">
                    <div class = "card-header">Clients List</div>
                    <div class = "card-body">
                        <a class = "btn btn-sm btn-success" href = "">Import CSV</a>
                        <a class = "btn btn-sm btn-warning" href = "clients/csv_export">Export CSV</a>

                        <div class = "float-right"><a href = "clients/post"><b>New Client</b></a></div>
                        <table class = "table mt-3">
                            <thead class = "thead-dark">
                            <tr>
                                <th scope = "col">#</th>
                                <th scope = "col">Name</th>
                                <th scope = "col">Gender</th>
                                <th scope = "col">Contact</th>
                                <th scope = "col">Mode of Contact</th>
                                <th scope = "col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $counter = 1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class = "text-center">
                                <th scope = "row"><?php echo e($counter++); ?></th>
                                <td><?php echo e($b['name']); ?></td>
                                <td><?php echo e($b['name']); ?></td>
                                <td><?php echo e($b['name']); ?></td>
                                <td><?php echo e($b['name']); ?></td>
                                <td>
                                    <a class = "btn btn-sm btn-success" href = "/blog/edit/<?php echo e($b['id']); ?>">Edit</a>
                                    <a class = "btn btn-sm btn-danger" href = "/blog/delete/<?php echo e($b['id']); ?>">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo $data->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-form\resources\views/users/index.blade.php ENDPATH**/ ?>